# Resources:
- Plotly Forum - https://community.plotly.com
- YouTube channel - https://www.youtube.com/charmingdata
- Dash Docs - https://dash.plotly.com/
- Color scales - https://plotly.com/python/builtin-colorscales/
- Plotly graphs - https://plotly.com/python/
- Plotly Express parameteres - https://plotly.github.io/plotly.py-docs/plotly.express.html
- Dash Bootstrap Components - https://dash-bootstrap-components.opensource.faculty.ai/
- Deploy app to the web with Dash-tools - https://github.com/andrew-hossack/dash-tools

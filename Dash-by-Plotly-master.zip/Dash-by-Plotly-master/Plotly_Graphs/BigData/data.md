Download the csv file for this app:
NYC 311 calls- https://drive.google.com/file/d/1EP549t-gj6lUgC_m3I6_kD9r0pESNL86/view?usp=sharing
Chicago crime- https://drive.google.com/file/d/1Ujywq7OH8xl31h7Uj4SQhZ1RX3hEvpdv/view?usp=sharing

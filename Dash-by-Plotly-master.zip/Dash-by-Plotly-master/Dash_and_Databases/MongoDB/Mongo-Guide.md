Click here to download the guide that I created to help you follow the tutorial.
  https://drive.google.com/file/d/1Z94SArM9azTcykVdNxmPQPAXeLfNtjJJ/view?usp=sharing

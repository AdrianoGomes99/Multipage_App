# Viz-for-Social-good dashboard app belongs to saiprakash12 on Github
This is a copy of his repository, which is located at:
https://github.com/saiprakash12/Viz-for-Social-good

To practice your Pull Requests go to: https://github.com/charmingdata/practice-pull-request

Download Pull Request Guide: 
https://docs.google.com/document/d/1wTzW6BAxWvfGwPmgkCt9z8cRn8SsG7iX/edit?usp=sharing&ouid=118003078876393636228&rtpof=true&sd=true

# Add opacity to line 15 inside your checklist.css form

.my_box_container {
  display: flex;
}

.my_box_input {
  cursor: pointer;
}

.my_box_label {
  background: #A5D6A7;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  opacity: 0.4;
}
